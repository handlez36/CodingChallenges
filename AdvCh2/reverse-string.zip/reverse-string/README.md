# Reverse a String


## Initial Setup

To run the test suite, first install `minitest` in your environment.

```
gem install minitest
```

## To run the test

Run the test file by running the command:

```
ruby string_reverser_test.rb
```

The test will fail, because line 3 of `string_reverser.rb` raises a "Not Implemented Error".