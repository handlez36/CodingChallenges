module StringReverser
	def self.reverse(input)
		fail "Not Implemented Error"
	end

end